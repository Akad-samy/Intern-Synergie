import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  codebar = ''//'5053990119004'//'3017620422003';
  favoris = [];
  historique = [];

  constructor() { }
  
}
