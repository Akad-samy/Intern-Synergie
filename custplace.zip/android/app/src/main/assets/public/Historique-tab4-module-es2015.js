(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Historique-tab4-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Historique/tab4.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Historique/tab4.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <h3 class=\"title\">Historique</h3>\n    <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" size=\"small\" *ngIf=\"this.data != null\">\n        <ion-fab-button (click)=\"clearStorage()\">\n            <ion-icon name=\"trash\"></ion-icon>\n        </ion-fab-button>\n    </ion-fab>\n    <div class=\"content\">\n        <ion-card class=\"product\" *ngFor=\"let d of data\">\n            <ion-grid fixed>\n                <ion-row (click)=\"showProduct(d._id)\">\n                    <ion-col size=\"3\" class=\"img-product\">\n                        <img src=\"{{d.image_small_url}}\" />\n                        <img src=\"../../../assets/logo-custplace.png\" *ngIf=\"d.image_small_url === undefined\" width=\"50\"\n                            style=\"opacity: .3;\">\n                    </ion-col>\n                    <ion-col size=\"9\">\n                        <ion-card-header>\n                            <ion-card-title>{{d.product_name}}</ion-card-title>\n                        </ion-card-header>\n                        <ion-card-content>\n                            <div class=\"nutri\">\n                                <div class=\"starRating\">\n                                    <p>3.2</p>\n                                    <div class=\"stars\">\n                                        <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                        <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                        <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                        <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                        <ion-icon slot=\"start\" name=\"star\"></ion-icon>\n                                    </div>\n                                    <p><small>(12)</small></p>\n                                </div>\n                                <img src=\"https://static.openfoodfacts.org/images/misc/nutriscore-{{d.nutrition_grades}}.svg\"\n                                    *ngIf='d.nutrition_grades != undefined' />\n\n                                <img src=\"../../../assets/nutriscor.png\" *ngIf='d.nutrition_grades === undefined'\n                                    style=\"opacity: .3;\" />\n\n                                <img src=\"https://static.openfoodfacts.org/images/misc/nova-group-{{d.nova_group}}.svg\"\n                                    *ngIf='d.nova_group != undefined'>\n\n                                <img src=\"../../../assets/nova-group-4.png\" *ngIf='d.nova_group === undefined'\n                                    style=\"opacity: .3;\">\n                            </div>\n                        </ion-card-content>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-card>\n    </div>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/Components/Historique/tab4-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/Components/Historique/tab4-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: Tab4PageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4PageRoutingModule", function() { return Tab4PageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tab4.page */ "./src/app/Components/Historique/tab4.page.ts");




const routes = [
    {
        path: '',
        component: _tab4_page__WEBPACK_IMPORTED_MODULE_3__["Tab4Page"]
    }
];
let Tab4PageRoutingModule = class Tab4PageRoutingModule {
};
Tab4PageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], Tab4PageRoutingModule);



/***/ }),

/***/ "./src/app/Components/Historique/tab4.module.ts":
/*!******************************************************!*\
  !*** ./src/app/Components/Historique/tab4.module.ts ***!
  \******************************************************/
/*! exports provided: Tab4PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4PageModule", function() { return Tab4PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _tab4_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab4-routing.module */ "./src/app/Components/Historique/tab4-routing.module.ts");
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab4.page */ "./src/app/Components/Historique/tab4.page.ts");







let Tab4PageModule = class Tab4PageModule {
};
Tab4PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _tab4_routing_module__WEBPACK_IMPORTED_MODULE_5__["Tab4PageRoutingModule"]
        ],
        declarations: [_tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]]
    })
], Tab4PageModule);



/***/ }),

/***/ "./src/app/Components/Historique/tab4.page.scss":
/*!******************************************************!*\
  !*** ./src/app/Components/Historique/tab4.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content .content .product {\n  width: 80%;\n  margin: 0.5rem auto;\n}\nion-content .content .product img {\n  height: 4rem;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\nion-content .content .product .img-product {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\nion-content .content .product ion-card-header {\n  padding-bottom: 0;\n}\nion-content .content .product ion-card-title {\n  color: var(--ion-color-primary);\n  font-size: 14px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n}\nion-content .content .product ion-card-content {\n  padding: 0;\n  margin: 0 1rem;\n}\nion-content .content .product ion-card-content .nutri .starRating {\n  margin-top: 0.5rem;\n}\nion-content .content .product ion-card-content .nutri .starRating p {\n  font-size: 14px;\n  padding: 0;\n  margin-right: 0.5rem;\n  display: inline;\n  font-weight: 600;\n  color: #000;\n}\nion-content .content .product ion-card-content .nutri .starRating p small {\n  margin-left: 0.5rem;\n  font-weight: 400 !important;\n}\nion-content .content .product ion-card-content .nutri .starRating .stars {\n  display: inline-block;\n  color: var(--ion-color-medium);\n}\nion-content .content .product ion-card-content .nutri .starRating .stars ion-icon {\n  font-size: 10px;\n}\nion-content .content .product ion-card-content .nutri .starRating .stars .checked {\n  color: var(--ion-color-warning);\n}\nion-content .content .product ion-card-content .nutri img {\n  height: 1.5rem;\n  margin: 0.5rem 0.2rem;\n}\nion-content .title {\n  color: var(--ion-color-primary);\n  font-size: 18px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n  margin: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ29tcG9uZW50cy9IaXN0b3JpcXVlL0M6XFxVc2Vyc1xcWW91Y29kZVxcRGVza3RvcFxcU3luZXJnaWVcXGN1c3RwbGFjZS9zcmNcXGFwcFxcQ29tcG9uZW50c1xcSGlzdG9yaXF1ZVxcdGFiNC5wYWdlLnNjc3MiLCJzcmMvYXBwL0NvbXBvbmVudHMvSGlzdG9yaXF1ZS90YWI0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFLSTtFQUdFLFVBQUE7RUFDQSxtQkFBQTtBQ05OO0FEWU07RUFDRSxZQUFBO0VBQ0Esc0JBQUE7S0FBQSxtQkFBQTtBQ1ZSO0FEYU07RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ1hSO0FEY007RUFDRSxpQkFBQTtBQ1pSO0FEZU07RUFDRSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHdCQUFBO0FDYlI7QURnQk07RUFDRSxVQUFBO0VBQ0EsY0FBQTtBQ2RSO0FEaUJVO0VBQ0Usa0JBQUE7QUNmWjtBRGlCWTtFQUNFLGVBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FDZmQ7QURpQmM7RUFDRSxtQkFBQTtFQUNBLDJCQUFBO0FDZmhCO0FEbUJZO0VBQ0UscUJBQUE7RUFDQSw4QkFBQTtBQ2pCZDtBRG1CYztFQUNFLGVBQUE7QUNqQmhCO0FEb0JjO0VBQ0UsK0JBQUE7QUNsQmhCO0FEdUJVO0VBQ0UsY0FBQTtFQUNBLHFCQUFBO0FDckJaO0FEaUNFO0VBQ0UsK0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx3QkFBQTtFQUNBLFlBQUE7QUMvQkoiLCJmaWxlIjoic3JjL2FwcC9Db21wb25lbnRzL0hpc3RvcmlxdWUvdGFiNC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcblxyXG4gIC5jb250ZW50e1xyXG4gICAgXHJcblxyXG4gICAgLnByb2R1Y3Qge1xyXG4gICAgICBcclxuICAgICAgLy8gdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICB3aWR0aDogODAlO1xyXG4gICAgICBtYXJnaW46IC41cmVtIGF1dG87XHJcbiAgXHJcbiAgICAgIC8vIGlvbi1jYXJkOmxhc3QtY2hpbGQge1xyXG4gICAgICAvLyAgIG1hcmdpbi1ib3R0b206IDZyZW07XHJcbiAgICAgIC8vIH1cclxuICBcclxuICAgICAgaW1nIHtcclxuICAgICAgICBoZWlnaHQ6IDRyZW07XHJcbiAgICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAuaW1nLXByb2R1Y3Qge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICBpb24tY2FyZC1oZWFkZXIge1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgICB9XHJcbiAgXHJcbiAgICAgIGlvbi1jYXJkLXRpdGxlIHtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAnUXVpY2tzYW5kJztcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICBpb24tY2FyZC1jb250ZW50IHtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgIG1hcmdpbjogMCAxcmVtO1xyXG4gIFxyXG4gICAgICAgIC5udXRyaSB7XHJcbiAgICAgICAgICAuc3RhclJhdGluZyB7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IC41cmVtO1xyXG4gIFxyXG4gICAgICAgICAgICBwIHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IC41cmVtO1xyXG4gICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICAgIGNvbG9yOiAjMDAwO1xyXG4gIFxyXG4gICAgICAgICAgICAgIHNtYWxsIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAuNXJlbTtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICBcclxuICAgICAgICAgICAgLnN0YXJzIHtcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gIFxyXG4gICAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICAgICAgLmNoZWNrZWQge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICBcclxuICAgICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMS41cmVtO1xyXG4gICAgICAgICAgICBtYXJnaW46IC41cmVtIC4ycmVtO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gIFxyXG4gIFxyXG4gICAgfVxyXG4gICAgXHJcbiAgfVxyXG5cclxuXHJcblxyXG4gIC50aXRsZSB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgIGZvbnQtZmFtaWx5OiAnUXVpY2tzYW5kJztcclxuICAgIG1hcmdpbjogMXJlbTtcclxuICB9XHJcbn0iLCJpb24tY29udGVudCAuY29udGVudCAucHJvZHVjdCB7XG4gIHdpZHRoOiA4MCU7XG4gIG1hcmdpbjogMC41cmVtIGF1dG87XG59XG5pb24tY29udGVudCAuY29udGVudCAucHJvZHVjdCBpbWcge1xuICBoZWlnaHQ6IDRyZW07XG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XG59XG5pb24tY29udGVudCAuY29udGVudCAucHJvZHVjdCAuaW1nLXByb2R1Y3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC5jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLWhlYWRlciB7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xufVxuaW9uLWNvbnRlbnQgLmNvbnRlbnQgLnByb2R1Y3QgaW9uLWNhcmQtdGl0bGUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtZmFtaWx5OiBcIlF1aWNrc2FuZFwiO1xufVxuaW9uLWNvbnRlbnQgLmNvbnRlbnQgLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCB7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMCAxcmVtO1xufVxuaW9uLWNvbnRlbnQgLmNvbnRlbnQgLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgLnN0YXJSYXRpbmcge1xuICBtYXJnaW4tdG9wOiAwLjVyZW07XG59XG5pb24tY29udGVudCAuY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyBwIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW4tcmlnaHQ6IDAuNXJlbTtcbiAgZGlzcGxheTogaW5saW5lO1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzAwMDtcbn1cbmlvbi1jb250ZW50IC5jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIHAgc21hbGwge1xuICBtYXJnaW4tbGVmdDogMC41cmVtO1xuICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XG59XG5pb24tY29udGVudCAuY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyAuc3RhcnMge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cbmlvbi1jb250ZW50IC5jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIC5zdGFycyBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbn1cbmlvbi1jb250ZW50IC5jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIC5zdGFycyAuY2hlY2tlZCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG59XG5pb24tY29udGVudCAuY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSBpbWcge1xuICBoZWlnaHQ6IDEuNXJlbTtcbiAgbWFyZ2luOiAwLjVyZW0gMC4ycmVtO1xufVxuaW9uLWNvbnRlbnQgLnRpdGxlIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LWZhbWlseTogXCJRdWlja3NhbmRcIjtcbiAgbWFyZ2luOiAxcmVtO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/Components/Historique/tab4.page.ts":
/*!****************************************************!*\
  !*** ./src/app/Components/Historique/tab4.page.ts ***!
  \****************************************************/
/*! exports provided: Tab4Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4Page", function() { return Tab4Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_service_global_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/service/global.service */ "./src/app/service/global.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");






const { Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["Plugins"];
let Tab4Page = class Tab4Page {
    constructor(globalService, router, loadingController, alertController) {
        this.globalService = globalService;
        this.router = router;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.data = [];
    }
    ngOnInit() { }
    ionViewWillEnter() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                mode: 'ios',
            });
            yield loading.present().then(() => {
                this.getStorageData();
            });
        });
    }
    getStorageData() {
        Storage.get({ key: 'historique' }).then((e) => {
            this.data = JSON.parse(e.value);
            this.loadingController.dismiss();
        }).catch(err => {
            console.log(err);
            this.loadingController.dismiss();
        });
    }
    clearStorage() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmation!',
                message: 'Etes-vous sûr de vouloir supprimer l\'historique ?',
                buttons: [
                    {
                        text: 'Non',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        },
                    },
                    {
                        text: 'Oui',
                        handler: () => {
                            Storage.remove({ key: 'historique' });
                            this.getStorageData();
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    showProduct(id) {
        this.globalService.codebar = id;
        this.router.navigateByUrl(`/tabs/tab1`);
    }
};
Tab4Page.ctorParameters = () => [
    { type: src_app_service_global_service__WEBPACK_IMPORTED_MODULE_1__["GlobalService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] }
];
Tab4Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-tab4',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tab4.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Historique/tab4.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tab4.page.scss */ "./src/app/Components/Historique/tab4.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_service_global_service__WEBPACK_IMPORTED_MODULE_1__["GlobalService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]])
], Tab4Page);



/***/ })

}]);
//# sourceMappingURL=Historique-tab4-module-es2015.js.map