function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Favoris-tab5-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Favoris/tab5.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Favoris/tab5.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsFavorisTab5PageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n    <h3 class=\"title\">Favoris</h3>\n    <ion-card class=\"product\" *ngFor=\"let favory of favoris\">\n        <ion-grid fixed>\n            <ion-row (click)=\"showProduct(favory._id)\">\n                <ion-col size=\"3\" class=\"img-product\">\n                    <img src=\"{{favory.image_small_url}}\" />\n                    <img src=\"../../../assets/logo-custplace.png\" *ngIf=\"favory.image_small_url === undefined\" width=\"50\"\n                        style=\"opacity: .3;\">\n                </ion-col>\n                <ion-col size=\"7\">\n                    <ion-card-header>\n                        <ion-card-title>{{favory.product_name}}</ion-card-title>\n                    </ion-card-header>\n                    <ion-card-content>\n                        <div class=\"nutri\">\n                            <div class=\"starRating\">\n                                <p>3.2</p>\n                                <div class=\"stars\">\n                                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                                    <ion-icon slot=\"start\" name=\"star\"></ion-icon>\n                                </div>\n                                <p><small>(12)</small></p>\n                            </div>\n                            <img src=\"https://static.openfoodfacts.org/images/misc/nutriscore-{{favory.nutrition_grades}}.svg\"\n                                *ngIf='favory.nutrition_grades != undefined' />\n\n                            <img src=\"../../../assets/nutriscor.png\" *ngIf='favory.nutrition_grades === undefined'\n                                style=\"opacity: .3;\" />\n\n                            <img src=\"https://static.openfoodfacts.org/images/misc/nova-group-{{favory.nova_group}}.svg\"\n                                *ngIf='favory.nova_group != undefined'>\n\n                            <img src=\"../../../assets/nova-group-4.png\" *ngIf='favory.nova_group === undefined'\n                                style=\"opacity: .3;\">\n                        </div>\n                    </ion-card-content>\n                </ion-col>\n                <ion-col size=\"2\" style=\"display: flex; justify-content: center; align-items: center;\">\n                    <ion-icon (click)=\"removeProduct(favory._id)\" name=\"trash\"\n                        style=\"color: #fff; background-color: var(--ion-color-danger); padding: 3px; border-radius: 5px; margin: 0 .3rem\">\n                    </ion-icon>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-card>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/Components/Favoris/tab5-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/Components/Favoris/tab5-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: Tab5PageRoutingModule */

  /***/
  function srcAppComponentsFavorisTab5RoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab5PageRoutingModule", function () {
      return Tab5PageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _tab5_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./tab5.page */
    "./src/app/Components/Favoris/tab5.page.ts");

    var routes = [{
      path: '',
      component: _tab5_page__WEBPACK_IMPORTED_MODULE_3__["Tab5Page"]
    }];

    var Tab5PageRoutingModule = function Tab5PageRoutingModule() {
      _classCallCheck(this, Tab5PageRoutingModule);
    };

    Tab5PageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], Tab5PageRoutingModule);
    /***/
  },

  /***/
  "./src/app/Components/Favoris/tab5.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/Components/Favoris/tab5.module.ts ***!
    \***************************************************/

  /*! exports provided: Tab5PageModule */

  /***/
  function srcAppComponentsFavorisTab5ModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab5PageModule", function () {
      return Tab5PageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _tab5_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./tab5-routing.module */
    "./src/app/Components/Favoris/tab5-routing.module.ts");
    /* harmony import */


    var _tab5_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tab5.page */
    "./src/app/Components/Favoris/tab5.page.ts");

    var Tab5PageModule = function Tab5PageModule() {
      _classCallCheck(this, Tab5PageModule);
    };

    Tab5PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tab5_routing_module__WEBPACK_IMPORTED_MODULE_5__["Tab5PageRoutingModule"]],
      declarations: [_tab5_page__WEBPACK_IMPORTED_MODULE_6__["Tab5Page"]]
    })], Tab5PageModule);
    /***/
  },

  /***/
  "./src/app/Components/Favoris/tab5.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/Components/Favoris/tab5.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsFavorisTab5PageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".product {\n  width: 80%;\n  margin: 0.5rem auto;\n}\n.product img {\n  height: 4rem;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n.product .img-product {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.product ion-card-header {\n  padding-bottom: 0;\n}\n.product ion-card-title {\n  color: var(--ion-color-primary);\n  font-size: 14px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n}\n.product ion-card-content {\n  padding: 0;\n  margin: 0 1rem;\n}\n.product ion-card-content .nutri .starRating {\n  margin-top: 0.5rem;\n}\n.product ion-card-content .nutri .starRating p {\n  font-size: 14px;\n  padding: 0;\n  margin-right: 0.5rem;\n  display: inline;\n  font-weight: 600;\n  color: #000;\n}\n.product ion-card-content .nutri .starRating p small {\n  margin-left: 0.5rem;\n  font-weight: 400 !important;\n}\n.product ion-card-content .nutri .starRating .stars {\n  display: inline-block;\n  color: var(--ion-color-medium);\n}\n.product ion-card-content .nutri .starRating .stars ion-icon {\n  font-size: 10px;\n}\n.product ion-card-content .nutri .starRating .stars .checked {\n  color: var(--ion-color-warning);\n}\n.product ion-card-content .nutri img {\n  height: 1.5rem;\n  margin: 0.5rem 0.2rem;\n}\n.title {\n  color: var(--ion-color-primary);\n  font-size: 18px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n  margin: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ29tcG9uZW50cy9GYXZvcmlzL0M6XFxVc2Vyc1xcWW91Y29kZVxcRGVza3RvcFxcU3luZXJnaWVcXGN1c3RwbGFjZS9zcmNcXGFwcFxcQ29tcG9uZW50c1xcRmF2b3Jpc1xcdGFiNS5wYWdlLnNjc3MiLCJzcmMvYXBwL0NvbXBvbmVudHMvRmF2b3Jpcy90YWI1LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLFVBQUE7RUFDQSxtQkFBQTtBQ0FKO0FERUk7RUFDRSxZQUFBO0VBQ0Esc0JBQUE7S0FBQSxtQkFBQTtBQ0FOO0FER0k7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0ROO0FESUk7RUFDRSxpQkFBQTtBQ0ZOO0FES0k7RUFDRSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHdCQUFBO0FDSE47QURNSTtFQUNFLFVBQUE7RUFDQSxjQUFBO0FDSk47QURPUTtFQUNFLGtCQUFBO0FDTFY7QURPVTtFQUNFLGVBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FDTFo7QURPWTtFQUNFLG1CQUFBO0VBQ0EsMkJBQUE7QUNMZDtBRFNVO0VBQ0UscUJBQUE7RUFDQSw4QkFBQTtBQ1BaO0FEU1k7RUFDRSxlQUFBO0FDUGQ7QURVWTtFQUNFLCtCQUFBO0FDUmQ7QURhUTtFQUNFLGNBQUE7RUFDQSxxQkFBQTtBQ1hWO0FEaUJFO0VBQ0UsK0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx3QkFBQTtFQUNBLFlBQUE7QUNkSiIsImZpbGUiOiJzcmMvYXBwL0NvbXBvbmVudHMvRmF2b3Jpcy90YWI1LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9kdWN0IHtcclxuICAgIC8vIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBtYXJnaW46IC41cmVtIGF1dG87XHJcbiAgXHJcbiAgICBpbWcge1xyXG4gICAgICBoZWlnaHQ6IDRyZW07XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgICB9XHJcbiAgXHJcbiAgICAuaW1nLXByb2R1Y3Qge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxuICBcclxuICAgIGlvbi1jYXJkLWhlYWRlciB7XHJcbiAgICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgaW9uLWNhcmQtdGl0bGUge1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAnUXVpY2tzYW5kJztcclxuICAgIH1cclxuICBcclxuICAgIGlvbi1jYXJkLWNvbnRlbnQge1xyXG4gICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICBtYXJnaW46IDAgMXJlbTtcclxuXHJcbiAgICAgIC5udXRyaSB7XHJcbiAgICAgICAgLnN0YXJSYXRpbmcge1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogLjVyZW07XHJcblxyXG4gICAgICAgICAgcCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAuNXJlbTtcclxuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMDtcclxuXHJcbiAgICAgICAgICAgIHNtYWxsIHtcclxuICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogLjVyZW07XHJcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLnN0YXJzIHtcclxuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcblxyXG4gICAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY2hlY2tlZCB7XHJcbiAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgIGhlaWdodDogMS41cmVtO1xyXG4gICAgICAgICAgbWFyZ2luOiAuNXJlbSAuMnJlbTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgLnRpdGxlIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgZm9udC1mYW1pbHk6ICdRdWlja3NhbmQnO1xyXG4gICAgbWFyZ2luOiAxcmVtO1xyXG4gIH0iLCIucHJvZHVjdCB7XG4gIHdpZHRoOiA4MCU7XG4gIG1hcmdpbjogMC41cmVtIGF1dG87XG59XG4ucHJvZHVjdCBpbWcge1xuICBoZWlnaHQ6IDRyZW07XG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XG59XG4ucHJvZHVjdCAuaW1nLXByb2R1Y3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLWhlYWRlciB7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xufVxuLnByb2R1Y3QgaW9uLWNhcmQtdGl0bGUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtZmFtaWx5OiBcIlF1aWNrc2FuZFwiO1xufVxuLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCB7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMCAxcmVtO1xufVxuLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgLnN0YXJSYXRpbmcge1xuICBtYXJnaW4tdG9wOiAwLjVyZW07XG59XG4ucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyBwIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW4tcmlnaHQ6IDAuNXJlbTtcbiAgZGlzcGxheTogaW5saW5lO1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzAwMDtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIHAgc21hbGwge1xuICBtYXJnaW4tbGVmdDogMC41cmVtO1xuICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XG59XG4ucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyAuc3RhcnMge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIC5zdGFycyBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIC5zdGFycyAuY2hlY2tlZCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG59XG4ucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSBpbWcge1xuICBoZWlnaHQ6IDEuNXJlbTtcbiAgbWFyZ2luOiAwLjVyZW0gMC4ycmVtO1xufVxuXG4udGl0bGUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtZmFtaWx5OiBcIlF1aWNrc2FuZFwiO1xuICBtYXJnaW46IDFyZW07XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/Components/Favoris/tab5.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/Components/Favoris/tab5.page.ts ***!
    \*************************************************/

  /*! exports provided: Tab5Page */

  /***/
  function srcAppComponentsFavorisTab5PageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab5Page", function () {
      return Tab5Page;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_service_global_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/service/global.service */
    "./src/app/service/global.service.ts");

    var Storage = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].Storage;

    var Tab5Page = /*#__PURE__*/function () {
      function Tab5Page(router, loadingController, globalService) {
        _classCallCheck(this, Tab5Page);

        this.router = router;
        this.loadingController = loadingController;
        this.globalService = globalService;
        this.favoris = [];
      }

      _createClass(Tab5Page, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      mode: 'ios'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present().then(function () {
                      _this.getStorageData();
                    });

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "getStorageData",
        value: function getStorageData() {
          var _this2 = this;

          Storage.get({
            key: 'favoris'
          }).then(function (e) {
            _this2.favoris = JSON.parse(e.value);

            if (_this2.loadingController.create()) {
              _this2.loadingController.dismiss();
            }
          });
        }
      }, {
        key: "showProduct",
        value: function showProduct(id) {
          this.globalService.codebar = id;
          this.router.navigateByUrl("/tabs/tab1");
        }
      }, {
        key: "removeProduct",
        value: function removeProduct(id) {
          var _this3 = this;

          Storage.get({
            key: 'favoris'
          }).then(function (e) {
            var data = JSON.parse(e.value);

            for (var i = 0; i < data.length; i++) {
              var Val = data[i];

              if (Val._id === id) {
                data.splice(i, 1);
              }
            }

            Storage.set({
              key: 'favoris',
              value: JSON.stringify(data)
            }).then(function (res) {
              console.log('data stored : ' + res);
            })["catch"](function (err) {
              console.log(err);
            });

            _this3.getStorageData();
          })["catch"](function (err) {
            console.log(err);

            _this3.loadingController.dismiss();
          });
        }
      }]);

      return Tab5Page;
    }();

    Tab5Page.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: src_app_service_global_service__WEBPACK_IMPORTED_MODULE_5__["GlobalService"]
      }];
    };

    Tab5Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tab5',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tab5.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Favoris/tab5.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./tab5.page.scss */
      "./src/app/Components/Favoris/tab5.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], src_app_service_global_service__WEBPACK_IMPORTED_MODULE_5__["GlobalService"]])], Tab5Page);
    /***/
  }
}]);
//# sourceMappingURL=Favoris-tab5-module-es5.js.map