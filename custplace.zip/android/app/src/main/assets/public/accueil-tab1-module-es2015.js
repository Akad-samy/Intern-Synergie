(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["accueil-tab1-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/accueil/tab1.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Components/accueil/tab1.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <div class=\"home\" *ngIf=\"this.globalService.codebar === ''\" (click)='searchCodebar()'>\n    <div>\n      <ion-icon name=\"barcode-outline\"></ion-icon>\n      <p>Appuyez ici et scanner le codebar de Votre produit</p>\n    </div>\n  </div>\n  \n  <div *ngIf=\"this.globalService.codebar != ''\">\n    <ion-card class=\"product\">\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"3\" class=\"imgProduct\">\n            <img src=\"{{prod.image_small_url}}\" />\n            <img src=\"../../../assets/logo-custplace.png\" *ngIf=\"prod.image_small_url === undefined\" width=\"50\"\n              style=\"opacity: .3;\">\n          </ion-col>\n          <ion-col size=\"9\">\n            <div style=\"float: right;z-index: 10; position: relative;\">\n              <ion-icon (click)=\"addFavoris()\" name=\"heart\" size=\"small\"\n                [ngStyle]=\"{ 'color': inFavoris === true ? danger : medium }\"></ion-icon>\n            </div>\n            <ion-card-header>\n              <ion-card-title>{{prod.product_name}}</ion-card-title>\n            </ion-card-header>\n            <ion-card-content>\n\n              <div class=\"nutri\">\n                <div class=\"starRating\">\n                  <p>{{this.globalService.moyenneScore}}</p>\n                  <div class=\"stars\" *ngFor='let key of [1,2,3,4,5]'>\n                    <ion-icon slot=\"start\" name=\"star\" id=\"{{key}}star\"\n                      [ngClass]=\"{ 'checked': key <= this.globalService.moyenneScore}\">\n                    </ion-icon>\n                  </div>\n                  <p><small>({{this.globalService.productReviews.length}})</small></p>\n                </div>\n                <img src=\"https://static.openfoodfacts.org/images/misc/nutriscore-{{prod.nutrition_grades}}.svg\"\n                  *ngIf='prod.nutrition_grades != undefined' />\n\n                <img src=\"../../../assets/nutriscor.png\" *ngIf='prod.nutrition_grades === undefined'\n                  style=\"opacity: .3;\" />\n\n                <img src=\"https://static.openfoodfacts.org/images/misc/nova-group-{{prod.nova_group}}.svg\"\n                  *ngIf='prod.nova_group != undefined'>\n\n                <img src=\"../../../assets/nova-group-4.png\" *ngIf='prod.nova_group === undefined' style=\"opacity: .3;\">\n              </div>\n            </ion-card-content>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n    <app-reviews></app-reviews>\n  </div>\n\n\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/reviews/reviews.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Components/reviews/reviews.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"review\">\n  <h3>Avis</h3>\n  <ion-icon class=\"text\" name=\"chatbox-ellipses-outline\" (click)=\"addReview()\"></ion-icon>\n</div>\n<div style=\"text-align: center;padding: 1rem;\" *ngIf=\"this.globalService.productReviews.length === 0\">\n  <ion-label>\n    <p>Appuyez sur <ion-icon class=\"text\" name=\"chatbox-ellipses-outline\"></ion-icon> pour ajouter votre avis</p>\n  </ion-label>\n</div>\n\n<div class=\"reviews\" *ngIf=\"this.globalService.productReviews.length != 0\">\n  <ion-grid fixed>\n    <ion-row *ngFor=\"let review of globalService.productReviews\">\n      <ion-col size=\"3\" style=\"text-align: center;\">\n        <ion-avatar>\n          <h3>{{review.nom?.substring(0,1) | uppercase}}</h3>\n        </ion-avatar>\n        <div class=\"stars\" *ngFor='let key of [1,2,3,4,5]'>\n          <ion-icon slot=\"start\" name=\"star\" id=\"{{key}}star\" [ngClass]=\"{ 'checked': key <= review.rating}\">\n          </ion-icon>\n        </div>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-label>\n          <div style=\"display: flex; justify-content: space-between;\">\n            <h2>{{review.nom}}</h2>\n            <p><small>6/04/2020 11:30</small></p>\n          </div>\n          <p>{{review.description}}</p>\n        </ion-label>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</div>");

/***/ }),

/***/ "./src/app/Components/accueil/tab1.module.ts":
/*!***************************************************!*\
  !*** ./src/app/Components/accueil/tab1.module.ts ***!
  \***************************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab1.page */ "./src/app/Components/accueil/tab1.page.ts");
/* harmony import */ var _reviews_reviews_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../reviews/reviews.component */ "./src/app/Components/reviews/reviews.component.ts");








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"] }]),
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"], _reviews_reviews_component__WEBPACK_IMPORTED_MODULE_7__["ReviewsComponent"]]
    })
], Tab1PageModule);



/***/ }),

/***/ "./src/app/Components/accueil/tab1.page.scss":
/*!***************************************************!*\
  !*** ./src/app/Components/accueil/tab1.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content ion-toolbar {\n  --background: translucent;\n}\n\nion-content {\n  --overflow: hidden;\n}\n\n.product {\n  text-align: left;\n  width: 80%;\n  margin: 1rem auto;\n}\n\n.product img {\n  height: 6rem;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n\n.product .imgProduct {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.product ion-card-header {\n  padding: 1rem;\n  padding-bottom: 0;\n  z-index: 0;\n}\n\n.product ion-card-title {\n  color: var(--ion-color-primary);\n  font-size: 16px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n}\n\n.product ion-card-content {\n  padding: 0;\n  margin: 0 1rem;\n}\n\n.product ion-card-content .nutri .starRating {\n  margin-top: 0.5rem;\n}\n\n.product ion-card-content .nutri .starRating p {\n  font-size: 14px;\n  padding: 0;\n  margin-right: 0.5rem;\n  display: inline;\n  font-weight: 600;\n  color: #000;\n}\n\n.product ion-card-content .nutri .starRating p small {\n  margin-left: 0.5rem;\n  font-weight: 400 !important;\n}\n\n.product ion-card-content .nutri .starRating .stars {\n  display: inline-block;\n  color: var(--ion-color-medium);\n}\n\n.product ion-card-content .nutri .starRating .stars ion-icon {\n  font-size: 10px;\n}\n\n.product ion-card-content .nutri .starRating .stars .checked {\n  color: var(--ion-color-warning);\n}\n\n.product ion-card-content .nutri img {\n  height: 1.5rem;\n  margin: 0.5rem 0.2rem;\n}\n\n.home {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 80vh;\n  text-align: center;\n}\n\n.home ion-icon {\n  font-size: 90px;\n  color: var(--ion-color-primary);\n  border-radius: 50%;\n  border: 5px solid var(--ion-color-warning);\n  padding: 15px;\n}\n\n.home p {\n  color: var(--ion-color-medium);\n  padding: 0 2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ29tcG9uZW50cy9hY2N1ZWlsL0M6XFxVc2Vyc1xcWW91Y29kZVxcRGVza3RvcFxcU3luZXJnaWVcXGN1c3RwbGFjZS9zcmNcXGFwcFxcQ29tcG9uZW50c1xcYWNjdWVpbFxcdGFiMS5wYWdlLnNjc3MiLCJzcmMvYXBwL0NvbXBvbmVudHMvYWNjdWVpbC90YWIxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxrQkFBQTtBQ0VGOztBRENBO0VBQ0UsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7QUNFRjs7QURFRTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtLQUFBLG1CQUFBO0FDQUo7O0FER0U7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0RKOztBRElFO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtBQ0ZKOztBREtFO0VBQ0UsK0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx3QkFBQTtBQ0hKOztBRE1FO0VBQ0UsVUFBQTtFQUNBLGNBQUE7QUNKSjs7QURPTTtFQUNFLGtCQUFBO0FDTFI7O0FET1E7RUFDRSxlQUFBO0VBQ0EsVUFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQ0xWOztBRE9VO0VBQ0UsbUJBQUE7RUFDQSwyQkFBQTtBQ0xaOztBRFNRO0VBQ0UscUJBQUE7RUFDQSw4QkFBQTtBQ1BWOztBRFNVO0VBQ0UsZUFBQTtBQ1BaOztBRFVVO0VBQ0UsK0JBQUE7QUNSWjs7QURhTTtFQUNFLGNBQUE7RUFDQSxxQkFBQTtBQ1hSOztBRGlCQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDZEY7O0FEZUU7RUFDRSxlQUFBO0VBQ0EsK0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0EsYUFBQTtBQ2JKOztBRGVFO0VBQ0UsOEJBQUE7RUFDQSxlQUFBO0FDYkoiLCJmaWxlIjoic3JjL2FwcC9Db21wb25lbnRzL2FjY3VlaWwvdGFiMS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNsdWNlbnQ7XG59XG5pb24tY29udGVudCB7XG4gIC0tb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnByb2R1Y3QgeyBcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgd2lkdGg6IDgwJTtcbiAgbWFyZ2luOiAxcmVtIGF1dG87XG4gIC8vIHBhZGRpbmc6IDFyZW07XG4gIC8vIGhlaWdodDogMjUwcHg7XG4gIFxuICBpbWcge1xuICAgIGhlaWdodDogNnJlbTtcbiAgICBvYmplY3QtZml0OiBjb250YWluO1xuICB9XG5cbiAgLmltZ1Byb2R1Y3R7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG5cbiAgaW9uLWNhcmQtaGVhZGVye1xuICAgIHBhZGRpbmc6IDFyZW07XG4gICAgcGFkZGluZy1ib3R0b206IDA7XG4gICAgei1pbmRleDogMDtcbiAgfVxuXG4gIGlvbi1jYXJkLXRpdGxlIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGZvbnQtZmFtaWx5OiAnUXVpY2tzYW5kJztcbiAgfVxuXG4gIGlvbi1jYXJkLWNvbnRlbnQge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgbWFyZ2luOiAwIDFyZW07XG4gIFxuICAgIC5udXRyaSB7XG4gICAgICAuc3RhclJhdGluZyB7XG4gICAgICAgIG1hcmdpbi10b3A6IC41cmVtO1xuXG4gICAgICAgIHAge1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgIG1hcmdpbi1yaWdodDogLjVyZW07XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lO1xuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgY29sb3I6ICMwMDA7XG5cbiAgICAgICAgICBzbWFsbCB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogLjVyZW07XG4gICAgICAgICAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnN0YXJzIHtcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuXG4gICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5jaGVja2VkIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGltZyB7XG4gICAgICAgIGhlaWdodDogMS41cmVtO1xuICAgICAgICBtYXJnaW46IC41cmVtIC4ycmVtO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4uaG9tZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBoZWlnaHQ6IDgwdmg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaW9uLWljb24ge1xuICAgIGZvbnQtc2l6ZTogOTBweDtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBib3JkZXI6IDVweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG4gICAgcGFkZGluZzogMTVweDtcbiAgfVxuICBwIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgcGFkZGluZzogMCAycmVtO1xuICB9XG59IiwiaW9uLWNvbnRlbnQgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zbHVjZW50O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnByb2R1Y3Qge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB3aWR0aDogODAlO1xuICBtYXJnaW46IDFyZW0gYXV0bztcbn1cbi5wcm9kdWN0IGltZyB7XG4gIGhlaWdodDogNnJlbTtcbiAgb2JqZWN0LWZpdDogY29udGFpbjtcbn1cbi5wcm9kdWN0IC5pbWdQcm9kdWN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4ucHJvZHVjdCBpb24tY2FyZC1oZWFkZXIge1xuICBwYWRkaW5nOiAxcmVtO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgei1pbmRleDogMDtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLXRpdGxlIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LWZhbWlseTogXCJRdWlja3NhbmRcIjtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDAgMXJlbTtcbn1cbi5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIHtcbiAgbWFyZ2luLXRvcDogMC41cmVtO1xufVxuLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgLnN0YXJSYXRpbmcgcCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luLXJpZ2h0OiAwLjVyZW07XG4gIGRpc3BsYXk6IGlubGluZTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICMwMDA7XG59XG4ucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyBwIHNtYWxsIHtcbiAgbWFyZ2luLWxlZnQ6IDAuNXJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xufVxuLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgLnN0YXJSYXRpbmcgLnN0YXJzIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG4ucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyAuc3RhcnMgaW9uLWljb24ge1xuICBmb250LXNpemU6IDEwcHg7XG59XG4ucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyAuc3RhcnMgLmNoZWNrZWQge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xufVxuLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgaW1nIHtcbiAgaGVpZ2h0OiAxLjVyZW07XG4gIG1hcmdpbjogMC41cmVtIDAuMnJlbTtcbn1cblxuLmhvbWUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgaGVpZ2h0OiA4MHZoO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uaG9tZSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogOTBweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBib3JkZXI6IDVweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG4gIHBhZGRpbmc6IDE1cHg7XG59XG4uaG9tZSBwIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICBwYWRkaW5nOiAwIDJyZW07XG59Il19 */");

/***/ }),

/***/ "./src/app/Components/accueil/tab1.page.ts":
/*!*************************************************!*\
  !*** ./src/app/Components/accueil/tab1.page.ts ***!
  \*************************************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_service_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/api.service */ "./src/app/service/api.service.ts");
/* harmony import */ var src_app_service_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/service/global.service */ "./src/app/service/global.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");








const { Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Plugins"];
let Tab1Page = class Tab1Page {
    constructor(apiService, globalService, loadingController, alertController, barcodeScanner, router) {
        this.apiService = apiService;
        this.globalService = globalService;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.barcodeScanner = barcodeScanner;
        this.router = router;
        // codeBar = '3600541982109'; // 3116430208941 // 3045140105502  // 7622210204424
        this.prod = '';
        this.inFavoris = false;
        this.danger = 'var(--ion-color-danger)';
        this.medium = 'var(--ion-color-medium)';
    }
    ionViewWillEnter() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                mode: 'ios',
            });
            yield loading.present().then(() => {
                this.getProduct();
                this.checkProdInFavoris();
            });
        });
    }
    // get product from codebar
    getProduct() {
        this.apiService.getData(this.globalService.codebar).subscribe((e) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            console.log(e);
            if (e['status_verbose'] === "product not found") { // product not found
                this.router.navigateByUrl(`/tabs/tab1`);
                const alert = yield this.alertController.create({
                    header: 'Custplace',
                    message: 'Produit non trouver! ',
                    buttons: ['OK'],
                    mode: 'ios',
                });
                yield alert.present();
            }
            if (e['code'] !== null) { // a default product with code = null, shows
                this.prod = e['product'];
                this.setStorageData(); // set in History
            }
            this.loadingController.dismiss();
        }), (err) => {
            console.log(err);
            this.loadingController.dismiss();
        });
    }
    setStorageData() {
        // get data from storage
        Storage.get({ key: 'historique' })
            .then((e) => {
            var data = JSON.parse(e.value);
            if (data === null) { //if no data exist in history
                data = [this.prod];
            }
            else {
                data.unshift(this.prod);
            }
            // Remove duplicated products
            this.globalService.historique = data.reduce((acc, current) => {
                const x = acc.find((item) => item._id === current._id);
                if (!x) {
                    return acc.concat([current]);
                }
                else {
                    return acc;
                }
            }, []);
            // set data to storage
            Storage.set({
                key: 'historique',
                value: JSON.stringify(this.globalService.historique),
            })
                .then((res) => {
                console.log('data stored : ' + res);
            })
                .catch((err) => {
                console.log(err);
            });
        })
            .catch((err) => {
            console.log(err);
            this.loadingController.dismiss();
        });
    }
    addFavoris() {
        Storage.get({ key: 'favoris' })
            .then((e) => {
            var data = JSON.parse(e.value);
            if (data === null) {
                data = [this.prod];
            }
            else {
                data.unshift(this.prod);
            }
            // Remove duplicated products
            this.globalService.favoris = data.reduce((acc, current) => {
                const x = acc.find((item) => item._id === current._id);
                if (!x) {
                    return acc.concat([current]);
                }
                else {
                    return acc;
                }
            }, []);
            // set data to storage
            Storage.set({
                key: 'favoris',
                value: JSON.stringify(this.globalService.favoris),
            })
                .then((res) => {
                console.log('data stored : ' + res);
            })
                .catch((err) => {
                console.log(err);
            });
        })
            .catch((err) => {
            console.log(err);
            this.loadingController.dismiss();
        });
        this.inFavoris = true;
    }
    checkProdInFavoris() {
        Storage.get({ key: 'favoris' })
            .then((e) => {
            const data = JSON.parse(e.value);
            if (data == null) {
                return;
            }
            this.inFavoris = data.filter(prod => prod._id === this.globalService.codebar).length > 0;
        })
            .catch((err) => {
            console.log(err);
        });
    }
    searchCodebar() {
        const options = {
            prompt: 'Encadrez un code barres avec le viseur pour le balayer',
        };
        this.barcodeScanner
            .scan(options)
            .then((barcodeData) => {
            this.globalService.codebar = barcodeData.text;
        })
            .catch((err) => {
            console.log('Error', err);
        });
    }
};
Tab1Page.ctorParameters = () => [
    { type: src_app_service_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: src_app_service_global_service__WEBPACK_IMPORTED_MODULE_3__["GlobalService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_6__["BarcodeScanner"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] }
];
Tab1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tab1',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tab1.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/accueil/tab1.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tab1.page.scss */ "./src/app/Components/accueil/tab1.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_service_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"],
        src_app_service_global_service__WEBPACK_IMPORTED_MODULE_3__["GlobalService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
        _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_6__["BarcodeScanner"],
        _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]])
], Tab1Page);



/***/ }),

/***/ "./src/app/Components/reviews/reviews.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/Components/reviews/reviews.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  left: 0;\n  position: absolute;\n  right: 0;\n}\n\n.review {\n  margin: 0 2rem;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.review h3 {\n  font-weight: 700;\n  font-style: \"Quicksand\";\n  font-size: 16px;\n}\n\n.review .text {\n  font-weight: bold;\n  background-color: var(--ion-color-primary);\n  color: #fff;\n  border-radius: 50%;\n  padding: 10px;\n  --ionicon-stroke-width: 46px;\n}\n\n.reviews {\n  height: 350px;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n}\n\n.reviews ion-grid {\n  overflow-y: auto;\n  padding-bottom: 7rem;\n  height: 100%;\n}\n\n.reviews ion-grid ::-webkit-scrollbar {\n  display: none;\n}\n\n.reviews ion-avatar {\n  height: 40px;\n  width: 40px;\n  margin: 0 auto;\n  background-color: var(--ion-color-medium);\n  color: #fff;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.reviews ion-avatar h3 {\n  margin: 0;\n}\n\n.reviews .stars {\n  display: inline-block;\n  font-size: 8px;\n  color: var(--ion-color-medium);\n}\n\n.reviews .stars .checked {\n  color: var(--ion-color-warning);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ29tcG9uZW50cy9yZXZpZXdzL0M6XFxVc2Vyc1xcWW91Y29kZVxcRGVza3RvcFxcU3luZXJnaWVcXGN1c3RwbGFjZS9zcmNcXGFwcFxcQ29tcG9uZW50c1xccmV2aWV3c1xccmV2aWV3cy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvQ29tcG9uZW50cy9yZXZpZXdzL3Jldmlld3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxPQUFBO0VBQ0Esa0JBQUE7RUFFQSxRQUFBO0FDQUo7O0FER0E7RUFDSSxjQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNBSjs7QURHSTtFQUNJLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FDRFI7O0FESUk7RUFDSSxpQkFBQTtFQUNBLDBDQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDRCQUFBO0FDRlI7O0FETUE7RUFFSSxhQUFBO0VBRUEsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUNMSjs7QURPSTtFQUNJLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0FDTFI7O0FETVE7RUFDSSxhQUFBO0FDSlo7O0FET0k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSx5Q0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0xSOztBRE9RO0VBQ0ksU0FBQTtBQ0xaOztBRFNJO0VBQ0kscUJBQUE7RUFDQSxjQUFBO0VBQ0EsOEJBQUE7QUNQUjs7QURRUTtFQUNFLCtCQUFBO0FDTlYiLCJmaWxlIjoic3JjL2FwcC9Db21wb25lbnRzL3Jldmlld3MvcmV2aWV3cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0e1xyXG4gICAgbGVmdDowO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgLy8gdG9wOiA1NSU7XHJcbiAgICByaWdodDogMDtcclxufVxyXG5cclxuLnJldmlldyB7XHJcbiAgICBtYXJnaW46IDAgMnJlbTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICAgIC8vIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwMHB4LCAwKTtcclxuICAgIGgzIHtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgIGZvbnQtc3R5bGU6ICdRdWlja3NhbmQnO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIH1cclxuXHJcbiAgICAudGV4dCB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgICAgIC0taW9uaWNvbi1zdHJva2Utd2lkdGg6IDQ2cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5yZXZpZXdzIHtcclxuICAgIC8vIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwMHB4LCAwKTtcclxuICAgIGhlaWdodDogMzUwcHg7XHJcbiAgICAvLyBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG5cclxuICAgIGlvbi1ncmlkIHtcclxuICAgICAgICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiA3cmVtO1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBpb24tYXZhdGFyIHtcclxuICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgd2lkdGg6IDQwcHg7XHJcbiAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgICAgICBoM3tcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuc3RhcnMge1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICBmb250LXNpemU6IDhweDtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgLmNoZWNrZWR7XHJcbiAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxufVxyXG5cclxuIiwiOmhvc3Qge1xuICBsZWZ0OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwO1xufVxuXG4ucmV2aWV3IHtcbiAgbWFyZ2luOiAwIDJyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbi5yZXZpZXcgaDMge1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXN0eWxlOiBcIlF1aWNrc2FuZFwiO1xuICBmb250LXNpemU6IDE2cHg7XG59XG4ucmV2aWV3IC50ZXh0IHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcGFkZGluZzogMTBweDtcbiAgLS1pb25pY29uLXN0cm9rZS13aWR0aDogNDZweDtcbn1cblxuLnJldmlld3Mge1xuICBoZWlnaHQ6IDM1MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLnJldmlld3MgaW9uLWdyaWQge1xuICBvdmVyZmxvdy15OiBhdXRvO1xuICBwYWRkaW5nLWJvdHRvbTogN3JlbTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuLnJldmlld3MgaW9uLWdyaWQgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG4ucmV2aWV3cyBpb24tYXZhdGFyIHtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogNDBweDtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICBjb2xvcjogI2ZmZjtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4ucmV2aWV3cyBpb24tYXZhdGFyIGgzIHtcbiAgbWFyZ2luOiAwO1xufVxuLnJldmlld3MgLnN0YXJzIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDhweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuLnJldmlld3MgLnN0YXJzIC5jaGVja2VkIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nKTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/Components/reviews/reviews.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/Components/reviews/reviews.component.ts ***!
  \*********************************************************/
/*! exports provided: ReviewsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewsComponent", function() { return ReviewsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _review_form_review_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../review-form/review-form.component */ "./src/app/Components/review-form/review-form.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_service_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/global.service */ "./src/app/service/global.service.ts");





let ReviewsComponent = class ReviewsComponent {
    constructor(modalController, globalService) {
        this.modalController = modalController;
        this.globalService = globalService;
    }
    ngOnInit() {
        console.log(this.globalService.productReviews);
    }
    addReview() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _review_form_review_form_component__WEBPACK_IMPORTED_MODULE_1__["ReviewFormComponent"],
                swipeToClose: true,
            });
            yield modal.present();
            console.log(this.globalService.productReviews);
        });
    }
};
ReviewsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: src_app_service_global_service__WEBPACK_IMPORTED_MODULE_4__["GlobalService"] }
];
ReviewsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-reviews',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./reviews.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/reviews/reviews.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./reviews.component.scss */ "./src/app/Components/reviews/reviews.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        src_app_service_global_service__WEBPACK_IMPORTED_MODULE_4__["GlobalService"]])
], ReviewsComponent);



/***/ })

}]);
//# sourceMappingURL=accueil-tab1-module-es2015.js.map