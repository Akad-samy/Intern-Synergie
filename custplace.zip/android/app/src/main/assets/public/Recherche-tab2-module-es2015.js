(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Recherche-tab2-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Recherche/tab2.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Recherche/tab2.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-toolbar color=\"primary\">\n\n  <ion-grid fixed>\n    <ion-row>\n      <ion-col [size]=\"myInput === '' ? 12 : 10\">\n        <ion-input type=\"text\" mode='md' [(ngModel)]=\"myInput\" placeholder=\"Nom du Produit\" pattern=\"[a-zA-Z]\"></ion-input>\n      </ion-col>\n      <ion-col size=\"2\" *ngIf=\"myInput != ''\">\n        <!-- <ion-icon slot=\"start\" name=\"search\" style=\"background-color: #fff; color: #fff;\"></ion-icon> -->\n        <ion-button @itemState (click)=\"getProduct($event)\" color=\"warning\" mode=\"md\" [hidden]=\"myInput === '' \">\n          <ion-icon slot=\"start\" name=\"search\" mode='ios'></ion-icon> \n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-toolbar>\n<ion-content [fullscreen]=\"true\">\n  <!-- <div *ngIf=\"myInput === ''\">\n\n  </div> -->\n  <div class=\"results\">\n    <ion-card class=\"product\" *ngFor=\"let prod of prods\">\n      <ion-grid fixed>\n        <ion-row (click)=\"showProduct(prod._id)\">\n          <ion-col size=\"3\" class=\"img-product\">\n            <img src=\"{{prod.image_small_url}}\" />\n            <img src=\"../../../assets/logo-custplace.png\" *ngIf=\"prod.image_small_url === undefined\" width=\"50\"\n              style=\"opacity: .3;\">\n          </ion-col>\n          <ion-col size=\"9\">\n            <ion-card-header>\n              <ion-card-title>{{prod.product_name}}</ion-card-title>\n            </ion-card-header>\n            <ion-card-content>\n              <div class=\"nutri\">\n                <div class=\"starRating\">\n                  <p>3.2</p>\n                  <div class=\"stars\">\n                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                    <ion-icon slot=\"start\" name=\"star\" class=\"checked\"></ion-icon>\n                    <ion-icon slot=\"start\" name=\"star\"></ion-icon>\n                  </div>\n                  <p><small>(12)</small></p>\n                </div>\n                <img src=\"https://static.openfoodfacts.org/images/misc/nutriscore-{{prod.nutrition_grades}}.svg\"\n                  *ngIf='prod.nutrition_grades != undefined' />\n\n                <img src=\"../../../assets/nutriscor.png\" *ngIf='prod.nutrition_grades === undefined'\n                  style=\"opacity: .3;\" />\n\n                <img src=\"https://static.openfoodfacts.org/images/misc/nova-group-{{prod.nova_group}}.svg\"\n                  *ngIf='prod.nova_group != undefined'>\n\n                <img src=\"../../../assets/nova-group-4.png\" *ngIf='prod.nova_group === undefined' style=\"opacity: .3;\">\n              </div>\n            </ion-card-content>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/Components/Recherche/tab2.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/Components/Recherche/tab2.module.ts ***!
  \*****************************************************/
/*! exports provided: tab2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tab2PageModule", function() { return tab2PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab2.page */ "./src/app/Components/Recherche/tab2.page.ts");







let tab2PageModule = class tab2PageModule {
};
tab2PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab2_page__WEBPACK_IMPORTED_MODULE_6__["tab2Page"] }])
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_6__["tab2Page"]]
    })
], tab2PageModule);



/***/ }),

/***/ "./src/app/Components/Recherche/tab2.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/Components/Recherche/tab2.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  height: 50%;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n}\nion-content .results {\n  overflow-y: auto;\n  padding-bottom: 7rem;\n  height: 100%;\n}\nion-content .results ::-webkit-scrollbar {\n  display: none;\n}\nion-content .product {\n  width: 80%;\n  margin: 0.5rem auto;\n}\nion-content .product img {\n  height: 4rem;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\nion-content .product .img-product {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\nion-content .product ion-card-header {\n  padding-bottom: 0;\n}\nion-content .product ion-card-title {\n  color: var(--ion-color-primary);\n  font-size: 14px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n}\nion-content .product ion-card-content {\n  padding: 0;\n  margin: 0 1rem;\n}\nion-content .product ion-card-content .nutri .starRating {\n  margin-top: 0.5rem;\n}\nion-content .product ion-card-content .nutri .starRating p {\n  font-size: 14px;\n  padding: 0;\n  margin-right: 0.5rem;\n  display: inline;\n  font-weight: 600;\n  color: #000;\n}\nion-content .product ion-card-content .nutri .starRating p small {\n  margin-left: 0.5rem;\n  font-weight: 400 !important;\n}\nion-content .product ion-card-content .nutri .starRating .stars {\n  display: inline-block;\n  color: var(--ion-color-medium);\n}\nion-content .product ion-card-content .nutri .starRating .stars ion-icon {\n  font-size: 10px;\n}\nion-content .product ion-card-content .nutri .starRating .stars .checked {\n  color: var(--ion-color-warning);\n}\nion-content .product ion-card-content .nutri img {\n  height: 1.5rem;\n  margin: 0.5rem 0.2rem;\n}\nion-content .title {\n  color: var(--ion-color-primary);\n  font-size: 18px;\n  font-weight: 700;\n  font-family: \"Quicksand\";\n  margin: 1rem;\n}\nion-toolbar ion-input {\n  background-color: #195876;\n  border-radius: 5px;\n  margin: 0;\n  padding: 0;\n}\nion-toolbar ion-button {\n  margin: 0;\n  padding: 0;\n  -webkit-animation: slideInSmooth ease-in 0.5;\n          animation: slideInSmooth ease-in 0.5;\n}\nion-toolbar ion-button ion-icon {\n  visibility: visible;\n  margin: 0;\n  padding: 0;\n}\n@-webkit-keyframes slideInSmooth {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n  }\n  100% {\n    -webkit-transform: translate3d(0, 0, 0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ29tcG9uZW50cy9SZWNoZXJjaGUvQzpcXFVzZXJzXFxZb3Vjb2RlXFxEZXNrdG9wXFxTeW5lcmdpZVxcY3VzdHBsYWNlL3NyY1xcYXBwXFxDb21wb25lbnRzXFxSZWNoZXJjaGVcXHRhYjIucGFnZS5zY3NzIiwic3JjL2FwcC9Db21wb25lbnRzL1JlY2hlcmNoZS90YWIyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLFdBQUE7RUFFQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQ0RGO0FER0U7RUFDRSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtBQ0RKO0FER0k7RUFDRSxhQUFBO0FDRE47QURLRTtFQUVFLFVBQUE7RUFDQSxtQkFBQTtBQ0pKO0FETUk7RUFDRSxZQUFBO0VBQ0Esc0JBQUE7S0FBQSxtQkFBQTtBQ0pOO0FET0k7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0xOO0FEUUk7RUFDRSxpQkFBQTtBQ05OO0FEU0k7RUFDRSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHdCQUFBO0FDUE47QURVSTtFQUNFLFVBQUE7RUFDQSxjQUFBO0FDUk47QURXUTtFQUNFLGtCQUFBO0FDVFY7QURXVTtFQUNFLGVBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FDVFo7QURXWTtFQUNFLG1CQUFBO0VBQ0EsMkJBQUE7QUNUZDtBRGFVO0VBQ0UscUJBQUE7RUFDQSw4QkFBQTtBQ1haO0FEYVk7RUFDRSxlQUFBO0FDWGQ7QURjWTtFQUNFLCtCQUFBO0FDWmQ7QURpQlE7RUFDRSxjQUFBO0VBQ0EscUJBQUE7QUNmVjtBRHFCRTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0FDbkJKO0FEd0JFO0VBQ0UseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FDckJKO0FEd0JFO0VBQ0UsU0FBQTtFQUNBLFVBQUE7RUFDQSw0Q0FBQTtVQUFBLG9DQUFBO0FDdEJKO0FEdUJJO0VBQ0UsbUJBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtBQ3JCTjtBRDJCQTtFQUNFO0lBQ0UsMkNBQUE7RUN4QkY7RUQwQkE7SUFDRSx1Q0FBQTtFQ3hCRjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvQ29tcG9uZW50cy9SZWNoZXJjaGUvdGFiMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XG4gIC8vIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwMHB4LCAwKTtcbiAgaGVpZ2h0OiA1MCU7XG4gIC8vIG1hcmdpbi1ib3R0b206IDFyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG92ZXJmbG93OiBoaWRkZW47XG5cbiAgLnJlc3VsdHMge1xuICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgcGFkZGluZy1ib3R0b206IDdyZW07XG4gICAgaGVpZ2h0OiAxMDAlO1xuXG4gICAgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cbiAgfVxuXG4gIC5wcm9kdWN0IHtcbiAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgd2lkdGg6IDgwJTtcbiAgICBtYXJnaW46IC41cmVtIGF1dG87XG5cbiAgICBpbWcge1xuICAgICAgaGVpZ2h0OiA0cmVtO1xuICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcbiAgICB9XG5cbiAgICAuaW1nLXByb2R1Y3Qge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICB9XG5cbiAgICBpb24tY2FyZC1oZWFkZXIge1xuICAgICAgcGFkZGluZy1ib3R0b206IDA7XG4gICAgfVxuXG4gICAgaW9uLWNhcmQtdGl0bGUge1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICBmb250LWZhbWlseTogJ1F1aWNrc2FuZCc7XG4gICAgfVxuXG4gICAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgICBwYWRkaW5nOiAwO1xuICAgICAgbWFyZ2luOiAwIDFyZW07XG4gICAgXG4gICAgICAubnV0cmkge1xuICAgICAgICAuc3RhclJhdGluZyB7XG4gICAgICAgICAgbWFyZ2luLXRvcDogLjVyZW07XG4gIFxuICAgICAgICAgIHAge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogLjVyZW07XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmU7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgY29sb3I6ICMwMDA7XG4gIFxuICAgICAgICAgICAgc21hbGwge1xuICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogLjVyZW07XG4gICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gIFxuICAgICAgICAgIC5zdGFycyB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIFxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgICAgICB9XG4gIFxuICAgICAgICAgICAgLmNoZWNrZWQge1xuICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICBcbiAgICAgICAgaW1nIHtcbiAgICAgICAgICBoZWlnaHQ6IDEuNXJlbTtcbiAgICAgICAgICBtYXJnaW46IC41cmVtIC4ycmVtO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLnRpdGxlIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGZvbnQtZmFtaWx5OiAnUXVpY2tzYW5kJztcbiAgICBtYXJnaW46IDFyZW07XG4gIH1cbn1cblxuaW9uLXRvb2xiYXIge1xuICBpb24taW5wdXR7XG4gICAgYmFja2dyb3VuZC1jb2xvcjojMTk1ODc2O1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBcbiAgfVxuICBpb24tYnV0dG9uIHtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBhbmltYXRpb246IHNsaWRlSW5TbW9vdGggZWFzZS1pbiAuNTtcbiAgICBpb24taWNvbiB7XG4gICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgICAgbWFyZ2luOiAwO1xuICAgICAgcGFkZGluZzogMDtcblxuICAgIH1cbiAgfVxufVxuXG5ALXdlYmtpdC1rZXlmcmFtZXMgc2xpZGVJblNtb290aCB7XG4gIDAlIHtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTEwMCUsMCwwKTtcbiAgfVxuICAxMDAlIHtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwwLDApO1xuICB9XG59IiwiaW9uLWNvbnRlbnQge1xuICBoZWlnaHQ6IDUwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbmlvbi1jb250ZW50IC5yZXN1bHRzIHtcbiAgb3ZlcmZsb3cteTogYXV0bztcbiAgcGFkZGluZy1ib3R0b206IDdyZW07XG4gIGhlaWdodDogMTAwJTtcbn1cbmlvbi1jb250ZW50IC5yZXN1bHRzIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lO1xufVxuaW9uLWNvbnRlbnQgLnByb2R1Y3Qge1xuICB3aWR0aDogODAlO1xuICBtYXJnaW46IDAuNXJlbSBhdXRvO1xufVxuaW9uLWNvbnRlbnQgLnByb2R1Y3QgaW1nIHtcbiAgaGVpZ2h0OiA0cmVtO1xuICBvYmplY3QtZml0OiBjb250YWluO1xufVxuaW9uLWNvbnRlbnQgLnByb2R1Y3QgLmltZy1wcm9kdWN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5pb24tY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1oZWFkZXIge1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbn1cbmlvbi1jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLXRpdGxlIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LWZhbWlseTogXCJRdWlja3NhbmRcIjtcbn1cbmlvbi1jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDAgMXJlbTtcbn1cbmlvbi1jb250ZW50IC5wcm9kdWN0IGlvbi1jYXJkLWNvbnRlbnQgLm51dHJpIC5zdGFyUmF0aW5nIHtcbiAgbWFyZ2luLXRvcDogMC41cmVtO1xufVxuaW9uLWNvbnRlbnQgLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgLnN0YXJSYXRpbmcgcCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luLXJpZ2h0OiAwLjVyZW07XG4gIGRpc3BsYXk6IGlubGluZTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICMwMDA7XG59XG5pb24tY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyBwIHNtYWxsIHtcbiAgbWFyZ2luLWxlZnQ6IDAuNXJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xufVxuaW9uLWNvbnRlbnQgLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgLnN0YXJSYXRpbmcgLnN0YXJzIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG5pb24tY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyAuc3RhcnMgaW9uLWljb24ge1xuICBmb250LXNpemU6IDEwcHg7XG59XG5pb24tY29udGVudCAucHJvZHVjdCBpb24tY2FyZC1jb250ZW50IC5udXRyaSAuc3RhclJhdGluZyAuc3RhcnMgLmNoZWNrZWQge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xufVxuaW9uLWNvbnRlbnQgLnByb2R1Y3QgaW9uLWNhcmQtY29udGVudCAubnV0cmkgaW1nIHtcbiAgaGVpZ2h0OiAxLjVyZW07XG4gIG1hcmdpbjogMC41cmVtIDAuMnJlbTtcbn1cbmlvbi1jb250ZW50IC50aXRsZSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgZm9udC1mYW1pbHk6IFwiUXVpY2tzYW5kXCI7XG4gIG1hcmdpbjogMXJlbTtcbn1cblxuaW9uLXRvb2xiYXIgaW9uLWlucHV0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE5NTg3NjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG59XG5pb24tdG9vbGJhciBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xuICBhbmltYXRpb246IHNsaWRlSW5TbW9vdGggZWFzZS1pbiAwLjU7XG59XG5pb24tdG9vbGJhciBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xufVxuXG5ALXdlYmtpdC1rZXlmcmFtZXMgc2xpZGVJblNtb290aCB7XG4gIDAlIHtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTEwMCUsIDAsIDApO1xuICB9XG4gIDEwMCUge1xuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/Components/Recherche/tab2.page.ts":
/*!***************************************************!*\
  !*** ./src/app/Components/Recherche/tab2.page.ts ***!
  \***************************************************/
/*! exports provided: tab2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tab2Page", function() { return tab2Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_service_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/api.service */ "./src/app/service/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_service_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/service/global.service */ "./src/app/service/global.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm2015/animations.js");







let tab2Page = class tab2Page {
    constructor(apiService, globalService, router, loadingController, alertController) {
        this.apiService = apiService;
        this.globalService = globalService;
        this.router = router;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.prods = [];
        this.myInput = '';
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                mode: 'ios',
            });
            yield loading.present().then(() => {
                this.getProduct();
            }).catch((err) => {
                console.log(err);
            });
        });
    }
    ionViewWillEnter() {
        // this.getProduct()
    }
    getProduct() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.myInput === undefined || this.myInput.match('.*\b[0-9]\b')) {
                const alert = yield this.alertController.create({
                    header: 'Custplace',
                    message: 'Veuiilez entrer le nom d\'un produit! ',
                    buttons: ['OK'],
                    mode: 'ios'
                });
                yield alert.present();
            }
            else {
                this.apiService.searchProductByName(this.myInput).subscribe((e) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                    // console.log(e)
                    if (e['count'] === 0) { // product not found
                        const alert = yield this.alertController.create({
                            header: 'Custplace',
                            message: 'Produit non trouver! ',
                            buttons: ['OK'],
                            mode: 'ios'
                        });
                        yield alert.present();
                    }
                    else {
                        this.prods = e['products'];
                    }
                    console.log(this.prods);
                    this.loadingController.dismiss();
                    this.myInput = '';
                }), err => {
                    console.log(err);
                    this.loadingController.dismiss();
                });
            }
        });
    }
    showProduct(id) {
        this.globalService.codebar = id;
        this.router.navigateByUrl(`/tabs/tab1`);
    }
};
tab2Page.ctorParameters = () => [
    { type: src_app_service_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: src_app_service_global_service__WEBPACK_IMPORTED_MODULE_4__["GlobalService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] }
];
tab2Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tab2',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tab2.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/Components/Recherche/tab2.page.html")).default,
        animations: [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["trigger"])('itemState', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["transition"])('void => *', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["style"])({ transform: 'translateX(100%)' }),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["animate"])('500ms ease-out')
                ]),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["transition"])('* => void', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["animate"])('500ms ease-in', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["style"])({ transform: 'translateX(-100%)' }))
                ])
            ])
        ],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tab2.page.scss */ "./src/app/Components/Recherche/tab2.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_service_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"],
        src_app_service_global_service__WEBPACK_IMPORTED_MODULE_4__["GlobalService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]])
], tab2Page);



/***/ })

}]);
//# sourceMappingURL=Recherche-tab2-module-es2015.js.map